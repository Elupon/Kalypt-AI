# AstraMind Android Starter

Минимальный Android-каркас приложения на Kotlin + Jetpack Compose.

## Важно
Это пока интерфейс приложения, а не готовый ИИ. Qwen/GGUF и движок инференса ещё не подключены. Чат сейчас показывает тестовое сообщение.

## Сборка
GitHub Actions workflow находится в `.github/workflows/android.yml`.
Он собирает `app-debug.apk` и публикует артефакт `AstraMind-debug`.

## Структура
Загружайте содержимое архива в корень репозитория, сохраняя пути и папки.
