package com.astramind.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

private data class ChatMessage(val text: String, val fromUser: Boolean)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                AstraMindScreen()
            }
        }
    }
}

@Composable
private fun AstraMindScreen() {
    var input by remember { mutableStateOf("") }
    var modelName by remember { mutableStateOf("Модель не загружена") }
    val messages = remember {
        mutableStateListOf(
            ChatMessage(
                "Привет! Я AstraMind. Пока это тестовый интерфейс: локальный движок Qwen ещё не подключён.",
                false
            )
        )
    }

    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("AstraMind", style = MaterialTheme.typography.headlineMedium)
        Text(modelName, style = MaterialTheme.typography.bodySmall)
        Text(
            "Следующий этап — подключить GGUF-модель Qwen и локальный inference engine.",
            style = MaterialTheme.typography.bodyMedium
        )
        HorizontalDivider()
        LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(messages) { message ->
                Surface(
                    color = if (message.fromUser) MaterialTheme.colorScheme.primaryContainer
                    else MaterialTheme.colorScheme.surfaceVariant,
                    shape = MaterialTheme.shapes.medium
                ) {
                    Text(message.text, modifier = Modifier.padding(12.dp))
                }
            }
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Напиши сообщение…") },
                maxLines = 4
            )
            Button(onClick = {
                val text = input.trim()
                if (text.isNotEmpty()) {
                    messages.add(ChatMessage(text, true))
                    messages.add(
                        ChatMessage(
                            "Сообщение принято интерфейсом. Ответ модели появится после подключения движка Qwen.",
                            false
                        )
                    )
                    input = ""
                }
            }) {
                Text("Отправить")
            }
        }
    }
}
