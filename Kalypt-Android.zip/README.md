# Kalypt AI

Создано ELUPON.

Локальный ИИ-чат для Android: Kotlin + Jetpack Compose + llama.cpp.
Модель (Qwen2.5, формат GGUF) скачивается при первом запуске и дальше работает без интернета.

## Сборка
Workflow `.github/workflows/android.yml` распаковывает `Kalypt-Android.zip`,
скачивает llama.cpp (закреплённая версия) и собирает `app-debug.apk`.
Готовый APK лежит в артефакте `Kalypt-debug` на странице запуска Actions.

## Модели
| Название | Основа | Размер |
|---|---|---|
| Kalypt Lite | Qwen2.5 1.5B Instruct (Q4_K_M) | ≈ 1,1 ГБ |
| Kalypt Core | Qwen2.5 3B Instruct (Q4_K_M) | ≈ 1,9 ГБ |
| Kalypt Max | Qwen2.5 7B Instruct (Q4_K_M) | ≈ 4,7 ГБ |

Лицензии моделей задают их авторы (Qwen). У 3B-версии лицензия исследовательская, не для коммерческого использования.
