package com.kalypt.app

import androidx.compose.foundation.Canvas
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.foundation.layout.size

/** Палитра Kalypt: «вуаль» (kalyptein, греч. «покрывать») на глубоком чернильном фоне. */
object K {
    val Ink = Color(0xFF0E1224)
    val Deep = Color(0xFF171E3B)
    val Raised = Color(0xFF232C58)
    val Line = Color(0xFF2B3563)
    val Veil = Color(0xFFB7A6FF)
    val VeilSoft = Color(0xFFE3DDFF)
    val VeilDeep = Color(0xFF302A78)
    val Mist = Color(0xFFE9ECFF)
    val Haze = Color(0xFF8E96C2)
    val Danger = Color(0xFFFF9B9B)
}

@Composable
fun KalyptTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = K.Veil,
            onPrimary = K.Ink,
            background = K.Ink,
            onBackground = K.Mist,
            surface = K.Deep,
            onSurface = K.Mist,
            surfaceVariant = K.Raised,
            onSurfaceVariant = K.Haze,
            outline = K.Line,
            error = K.Danger,
        ),
        content = content,
    )
}

/** Знак Kalypt: два прозрачных круга, наложенных друг на друга, как вуаль. */
@Composable
fun KalyptMark(markSize: Dp, modifier: Modifier = Modifier) {
    Canvas(modifier.size(markSize)) {
        val r = this.size.minDimension * 0.30f
        val cy = this.size.height / 2f
        drawCircle(K.Veil.copy(alpha = 0.6f), r, Offset(this.size.width * 0.38f, cy))
        drawCircle(K.VeilSoft.copy(alpha = 0.85f), r, Offset(this.size.width * 0.62f, cy))
    }
}
