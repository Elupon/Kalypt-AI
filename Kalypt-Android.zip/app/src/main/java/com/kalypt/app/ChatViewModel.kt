package com.kalypt.app

import android.app.Application
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.Executors

enum class Phase { Setup, Loading, Chat }
enum class Role { User, Assistant }

data class Msg(val id: Long, val role: Role, val text: String, val isError: Boolean = false)

private const val CTX = 4096
private const val MAX_NEW = 1024
private const val SYSTEM =
    "Ты — Kalypt, дружелюбный ИИ-ассистент, созданный ELUPON. " +
        "Отвечай на языке пользователя, по умолчанию по-русски. Отвечай ясно и по делу."

class ChatViewModel(app: Application) : AndroidViewModel(app) {

    private val prefs = app.getSharedPreferences("kalypt", 0)
    private val modelsDir = File(app.filesDir, "models")
    private val main = Handler(Looper.getMainLooper())
    private val llamaDispatcher = Executors.newSingleThreadExecutor().asCoroutineDispatcher()
    private val threads = (Runtime.getRuntime().availableProcessors() / 2).coerceIn(2, 6)

    var phase by mutableStateOf(Phase.Setup)
        private set
    var loadedModel by mutableStateOf<ModelInfo?>(null)
        private set
    var downloaded by mutableStateOf(setOf<String>())
        private set
    var downloadingId by mutableStateOf<String?>(null)
        private set
    var downloadDone by mutableLongStateOf(0L)
        private set
    var downloadTotal by mutableLongStateOf(0L)
        private set
    var error by mutableStateOf<String?>(null)
        private set
    var isGenerating by mutableStateOf(false)
        private set
    var speed by mutableStateOf<String?>(null)
        private set

    val messages = mutableStateListOf<Msg>()

    private var nextId = 1L
    private var downloadJob: Job? = null
    @Volatile
    private var stopRequested = false

    init {
        refreshDownloaded()
        val saved = prefs.getString("model", null)
        val info = ModelCatalog.all.firstOrNull { it.id == saved }
        if (info != null && info.id in downloaded) loadModel(info)
    }

    private fun refreshDownloaded() {
        downloaded = ModelCatalog.all
            .filter { File(modelsDir, it.fileName).exists() }
            .map { it.id }
            .toSet()
    }

    // ---------- модели ----------

    fun startDownload(info: ModelInfo) {
        if (downloadJob?.isActive == true) return
        error = null
        downloadingId = info.id
        downloadDone = 0L
        downloadTotal = info.approxBytes
        downloadJob = viewModelScope.launch {
            try {
                ModelDownloader.download(info, modelsDir) { done, total ->
                    main.post {
                        downloadDone = done
                        downloadTotal = total
                    }
                }
                refreshDownloaded()
                downloadingId = null
                loadModel(info)
            } catch (e: CancellationException) {
                downloadingId = null
                throw e
            } catch (e: Exception) {
                downloadingId = null
                error = "Загрузка прервана: ${e.message ?: "нет связи"}. Нажмите «Скачать», чтобы продолжить с того же места."
            }
        }
    }

    fun cancelDownload() {
        downloadJob?.cancel()
    }

    fun deleteModel(info: ModelInfo) {
        if (isGenerating) return
        viewModelScope.launch {
            if (loadedModel?.id == info.id) {
                withContext(llamaDispatcher) { LlamaBridge.release() }
                loadedModel = null
                messages.clear()
            }
            File(modelsDir, info.fileName).delete()
            File(modelsDir, info.fileName + ".part").delete()
            refreshDownloaded()
        }
    }

    fun loadModel(info: ModelInfo) {
        if (isGenerating) return
        if (loadedModel?.id == info.id) {
            phase = Phase.Chat
            return
        }
        error = null
        phase = Phase.Loading
        viewModelScope.launch {
            val ok = withContext(llamaDispatcher) {
                LlamaBridge.release()
                LlamaBridge.load(File(modelsDir, info.fileName).absolutePath, CTX, threads)
            }
            if (ok) {
                loadedModel = info
                prefs.edit().putString("model", info.id).apply()
                messages.clear()
                speed = null
                phase = Phase.Chat
            } else {
                loadedModel = null
                error = "Не удалось запустить модель. Возможно, не хватает памяти: выберите модель поменьше."
                phase = Phase.Setup
            }
        }
    }

    fun openModels() {
        if (!isGenerating) phase = Phase.Setup
    }

    fun backToChat() {
        if (loadedModel != null) phase = Phase.Chat
    }

    // ---------- чат ----------

    fun newChat() {
        stopRequested = true
        messages.clear()
        speed = null
        viewModelScope.launch(llamaDispatcher) { LlamaBridge.reset() }
    }

    fun stop() {
        stopRequested = true
    }

    fun send(raw: String) {
        val text = raw.trim()
        if (text.isEmpty() || isGenerating || phase != Phase.Chat) return

        val history = messages.filter { !it.isError }.takeLast(6)
        messages.add(Msg(nextId++, Role.User, text))
        val aid = nextId++
        messages.add(Msg(aid, Role.Assistant, ""))
        isGenerating = true
        stopRequested = false

        viewModelScope.launch {
            val sb = StringBuilder()
            var lastPush = 0L
            val cb = TokenCallback { piece ->
                sb.append(piece)
                val t = SystemClock.uptimeMillis()
                if (t - lastPush > 50) {
                    lastPush = t
                    val snapshot = sb.toString()
                    main.post { updateMsg(aid, snapshot) }
                }
                !stopRequested
            }

            val t0 = SystemClock.elapsedRealtime()
            val produced = withContext(llamaDispatcher) { generate(history, text, cb) }
            val seconds = (SystemClock.elapsedRealtime() - t0) / 1000f

            if (produced < 0) {
                replaceMsg(aid, "Не удалось получить ответ (код $produced). Начните новый чат.", true)
            } else {
                updateMsg(aid, sb.toString().trim())
                if (produced > 0 && seconds > 0f) {
                    speed = "%.1f ток/с".format(produced / seconds)
                }
            }
            isGenerating = false
        }
    }

    private fun generate(history: List<Msg>, text: String, cb: TokenCallback): Int {
        if (LlamaBridge.nPast() > CTX - 1200) LlamaBridge.reset()
        val fresh = LlamaBridge.nPast() == 0
        var r = LlamaBridge.generate(buildPrompt(history, text, fresh), MAX_NEW, cb)
        if (r == -2) {
            LlamaBridge.reset()
            r = LlamaBridge.generate(buildPrompt(emptyList(), text, true), MAX_NEW, cb)
        }
        return r
    }

    /** ChatML-формат Qwen. В продолжении диалога модель уже «помнит» прошлые реплики в KV-кэше. */
    private fun buildPrompt(history: List<Msg>, text: String, fresh: Boolean): String {
        val sb = StringBuilder()
        if (fresh) {
            sb.append("<|im_start|>system\n").append(SYSTEM).append("<|im_end|>\n")
            for (m in history) {
                val role = if (m.role == Role.User) "user" else "assistant"
                sb.append("<|im_start|>").append(role).append('\n').append(m.text).append("<|im_end|>\n")
            }
        } else {
            sb.append("<|im_end|>\n")
        }
        sb.append("<|im_start|>user\n").append(text).append("<|im_end|>\n<|im_start|>assistant\n")
        return sb.toString()
    }

    private fun updateMsg(id: Long, text: String) {
        val i = messages.indexOfLast { it.id == id }
        if (i >= 0) messages[i] = messages[i].copy(text = text)
    }

    private fun replaceMsg(id: Long, text: String, isError: Boolean) {
        val i = messages.indexOfLast { it.id == id }
        if (i >= 0) messages[i] = messages[i].copy(text = text, isError = isError)
    }

    override fun onCleared() {
        stopRequested = true
        llamaDispatcher.executor.execute { LlamaBridge.release() }
        super.onCleared()
    }
}
