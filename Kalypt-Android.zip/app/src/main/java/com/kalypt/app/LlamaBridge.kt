package com.kalypt.app

/** Колбэк потоковой генерации. Верните false, чтобы остановить ответ. */
fun interface TokenCallback {
    fun onToken(piece: String): Boolean
}

/** Мост к llama.cpp (см. cpp/native-lib.cpp). Вызывать только из одного потока. */
object LlamaBridge {
    init {
        System.loadLibrary("kalypt")
    }

    external fun load(path: String, nCtx: Int, nThreads: Int): Boolean
    external fun generate(prompt: String, maxTokens: Int, cb: TokenCallback): Int
    external fun reset()
    external fun nPast(): Int
    external fun release()
}
