package com.kalypt.app

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.ensureActive
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

data class ModelInfo(
    val id: String,
    val title: String,
    val base: String,
    val note: String,
    val sizeLabel: String,
    val approxBytes: Long,
    val fileName: String,
    val url: String,
)

object ModelCatalog {
    val all = listOf(
        ModelInfo(
            id = "lite",
            title = "Kalypt Lite",
            base = "Qwen2.5 1.5B",
            note = "Отвечает быстро, подходит для любого телефона.",
            sizeLabel = "1,1 ГБ",
            approxBytes = 1_120_000_000L,
            fileName = "Qwen2.5-1.5B-Instruct-Q4_K_M.gguf",
            url = "https://huggingface.co/bartowski/Qwen2.5-1.5B-Instruct-GGUF/resolve/main/Qwen2.5-1.5B-Instruct-Q4_K_M.gguf",
        ),
        ModelInfo(
            id = "core",
            title = "Kalypt Core",
            base = "Qwen2.5 3B",
            note = "Баланс скорости и качества. Рекомендуем начать с неё.",
            sizeLabel = "1,9 ГБ",
            approxBytes = 1_930_000_000L,
            fileName = "Qwen2.5-3B-Instruct-Q4_K_M.gguf",
            url = "https://huggingface.co/bartowski/Qwen2.5-3B-Instruct-GGUF/resolve/main/Qwen2.5-3B-Instruct-Q4_K_M.gguf",
        ),
        ModelInfo(
            id = "max",
            title = "Kalypt Max",
            base = "Qwen2.5 7B",
            note = "Самые связные ответы. Нужен телефон с 12 ГБ памяти и больше.",
            sizeLabel = "4,7 ГБ",
            approxBytes = 4_680_000_000L,
            fileName = "Qwen2.5-7B-Instruct-Q4_K_M.gguf",
            url = "https://huggingface.co/bartowski/Qwen2.5-7B-Instruct-GGUF/resolve/main/Qwen2.5-7B-Instruct-Q4_K_M.gguf",
        ),
    )
}

object ModelDownloader {
    /** Скачивает файл с докачкой. Прогресс: (скачано, всего). */
    suspend fun download(
        info: ModelInfo,
        dir: File,
        onProgress: (Long, Long) -> Unit,
    ): File = withContext(Dispatchers.IO) {
        dir.mkdirs()
        val target = File(dir, info.fileName)
        if (target.exists()) return@withContext target
        val part = File(dir, info.fileName + ".part")
        var existing = if (part.exists()) part.length() else 0L

        val conn = URL(info.url).openConnection() as HttpURLConnection
        conn.connectTimeout = 20_000
        conn.readTimeout = 30_000
        conn.instanceFollowRedirects = true
        conn.setRequestProperty("User-Agent", "Kalypt/0.2 (ELUPON)")
        if (existing > 0) conn.setRequestProperty("Range", "bytes=$existing-")

        try {
            conn.connect()
            val code = conn.responseCode
            if (code == 416 && part.exists()) {
                part.renameTo(target)
                return@withContext target
            }
            if (code != 200 && code != 206) throw IOException("сервер ответил $code")

            val append = code == 206
            if (!append) existing = 0L
            val total = existing + conn.contentLengthLong
            var done = existing
            var lastReport = 0L

            conn.inputStream.use { input ->
                FileOutputStream(part, append).use { out ->
                    val buf = ByteArray(256 * 1024)
                    while (true) {
                        ensureActive()
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        done += n
                        val now = System.currentTimeMillis()
                        if (now - lastReport > 250) {
                            lastReport = now
                            onProgress(done, total)
                        }
                    }
                }
            }
            onProgress(done, total)
            if (!part.renameTo(target)) throw IOException("не удалось сохранить файл")
            target
        } finally {
            conn.disconnect()
        }
    }
}
