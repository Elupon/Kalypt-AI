package com.kalypt.app

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun KalyptApp(vm: ChatViewModel) {
    var showAbout by remember { mutableStateOf(false) }
    Box(Modifier.fillMaxSize().background(K.Ink)) {
        when (vm.phase) {
            Phase.Setup -> SetupScreen(vm) { showAbout = true }
            Phase.Loading -> LoadingScreen()
            Phase.Chat -> ChatScreen(vm) { showAbout = true }
        }
    }
    if (showAbout) AboutDialog { showAbout = false }
}

// ───────────────────────── Загрузка ─────────────────────────

@Composable
private fun LoadingScreen() {
    val t = rememberInfiniteTransition(label = "load")
    val a by t.animateFloat(
        initialValue = 0.4f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "a",
    )
    Column(
        Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        KalyptMark(72.dp, Modifier.alpha(a))
        Spacer(Modifier.height(20.dp))
        Text("Запускаю модель…", color = K.Haze, fontSize = 16.sp)
    }
}

// ───────────────────────── Выбор модели ─────────────────────────

@Composable
private fun SetupScreen(vm: ChatViewModel, onAbout: () -> Unit) {
    BackHandler(enabled = vm.loadedModel != null) { vm.backToChat() }

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 22.dp, vertical = 16.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            KalyptMark(34.dp)
            Spacer(Modifier.width(10.dp))
            Text("Kalypt", color = K.Mist, fontFamily = FontFamily.Serif, fontSize = 26.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.weight(1f))
            if (vm.loadedModel != null) {
                TextButton(onClick = { vm.backToChat() }) { Text("К чату", color = K.Veil) }
            }
        }
        Spacer(Modifier.height(30.dp))
        Text("Выберите модель", color = K.Mist, fontFamily = FontFamily.Serif, fontSize = 30.sp, lineHeight = 36.sp)
        Spacer(Modifier.height(10.dp))
        Text(
            "Модель скачивается один раз и дальше работает без интернета. Пока идёт загрузка, держите приложение открытым.",
            color = K.Haze, fontSize = 15.sp, lineHeight = 22.sp,
        )
        Spacer(Modifier.height(24.dp))

        ModelCatalog.all.forEach { info ->
            ModelCard(vm, info)
            Spacer(Modifier.height(14.dp))
        }

        vm.error?.let {
            Spacer(Modifier.height(4.dp))
            Text(it, color = K.Danger, fontSize = 14.sp, lineHeight = 20.sp)
        }

        Spacer(Modifier.height(28.dp))
        Text(
            "Создано ELUPON",
            color = K.Haze, fontSize = 13.sp, textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth().clickable { onAbout() }.padding(12.dp),
        )
    }
}

@Composable
private fun ModelCard(vm: ChatViewModel, info: ModelInfo) {
    val isDownloading = vm.downloadingId == info.id
    val isReady = info.id in vm.downloaded
    val isActive = vm.loadedModel?.id == info.id
    val shape = RoundedCornerShape(22.dp)

    Column(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(K.Deep)
            .border(1.dp, if (isActive) K.Veil else K.Line, shape)
            .padding(18.dp),
    ) {
        Row(verticalAlignment = Alignment.Bottom) {
            Text(info.title, color = K.Mist, fontFamily = FontFamily.Serif, fontSize = 21.sp, modifier = Modifier.weight(1f))
            Text(info.sizeLabel, color = K.Haze, fontSize = 14.sp)
        }
        Spacer(Modifier.height(2.dp))
        Text(info.base, color = K.Veil, fontSize = 13.sp)
        Spacer(Modifier.height(8.dp))
        Text(info.note, color = K.Haze, fontSize = 14.sp, lineHeight = 20.sp)
        Spacer(Modifier.height(14.dp))

        when {
            isDownloading -> {
                val fraction = if (vm.downloadTotal > 0) (vm.downloadDone.toFloat() / vm.downloadTotal).coerceIn(0f, 1f) else 0f
                LinearProgressIndicator(
                    progress = { fraction },
                    modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape),
                    color = K.Veil,
                    trackColor = K.Raised,
                )
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "${(fraction * 100).toInt()}%  ${gb(vm.downloadDone)} из ${gb(vm.downloadTotal)}",
                        color = K.Haze, fontSize = 13.sp, modifier = Modifier.weight(1f),
                    )
                    TextButton(onClick = { vm.cancelDownload() }) { Text("Отменить", color = K.Veil) }
                }
            }
            isReady -> {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Button(
                        onClick = { vm.loadModel(info) },
                        colors = ButtonDefaults.buttonColors(containerColor = K.Veil, contentColor = K.Ink),
                    ) { Text(if (isActive) "Продолжить чат" else "Открыть чат") }
                    Spacer(Modifier.weight(1f))
                    TextButton(onClick = { vm.deleteModel(info) }) { Text("Удалить", color = K.Haze) }
                }
            }
            else -> {
                OutlinedButton(
                    onClick = { vm.startDownload(info) },
                    enabled = vm.downloadingId == null,
                    border = BorderStroke(1.dp, K.Veil),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = K.Veil, disabledContentColor = K.Haze),
                ) { Text("Скачать") }
            }
        }
    }
}

private fun gb(bytes: Long): String = "%.2f ГБ".format(bytes / 1_000_000_000.0)

// ───────────────────────── Чат ─────────────────────────

@Composable
private fun ChatScreen(vm: ChatViewModel, onAbout: () -> Unit) {
    var input by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val lastLen = vm.messages.lastOrNull()?.text?.length ?: 0

    LaunchedEffect(vm.messages.size, lastLen) {
        if (vm.messages.isNotEmpty()) listState.scrollToItem(vm.messages.size)
    }

    Column(Modifier.fillMaxSize()) {
        TopBar(vm, onAbout)
        HorizontalDivider(color = K.Line)
        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (vm.messages.isEmpty()) {
                EmptyState { vm.send(it) }
            } else {
                LazyColumn(
                    state = listState,
                    contentPadding = PaddingValues(horizontal = 18.dp, vertical = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(20.dp),
                ) {
                    items(vm.messages, key = { it.id }) { m ->
                        MessageRow(m, thinking = vm.isGenerating && m.id == vm.messages.lastOrNull()?.id && m.text.isEmpty())
                    }
                    item { Spacer(Modifier.height(1.dp)) }
                }
            }
        }
        InputBar(
            value = input,
            onChange = { input = it },
            generating = vm.isGenerating,
            onSend = {
                vm.send(input)
                input = ""
            },
            onStop = { vm.stop() },
        )
    }
}

@Composable
private fun TopBar(vm: ChatViewModel, onAbout: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 18.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        KalyptMark(26.dp)
        Spacer(Modifier.width(8.dp))
        Text("Kalypt", color = K.Mist, fontFamily = FontFamily.Serif, fontSize = 22.sp, fontWeight = FontWeight.Medium)
        Spacer(Modifier.weight(1f))

        val chipShape = RoundedCornerShape(16.dp)
        Row(
            Modifier
                .clip(chipShape)
                .border(1.dp, K.Line, chipShape)
                .clickable(enabled = !vm.isGenerating) { vm.openModels() }
                .padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(Modifier.size(7.dp).clip(CircleShape).background(K.Veil))
            Spacer(Modifier.width(8.dp))
            Column {
                Text(vm.loadedModel?.title ?: "", color = K.Mist, fontSize = 13.sp)
                vm.speed?.let { Text(it, color = K.Haze, fontSize = 11.sp) }
            }
        }
        Spacer(Modifier.width(6.dp))
        RoundIconButton(onClick = { vm.newChat() }) {
            Canvas(Modifier.size(18.dp)) {
                val s = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round)
                drawLine(K.Mist, Offset(size.width / 2, 1f), Offset(size.width / 2, size.height - 1f), strokeWidth = s.width, cap = StrokeCap.Round)
                drawLine(K.Mist, Offset(1f, size.height / 2), Offset(size.width - 1f, size.height / 2), strokeWidth = s.width, cap = StrokeCap.Round)
            }
        }
        RoundIconButton(onClick = onAbout) {
            Text("i", color = K.Haze, fontFamily = FontFamily.Serif, fontSize = 20.sp)
        }
    }
}

@Composable
private fun RoundIconButton(onClick: () -> Unit, content: @Composable BoxScope.() -> Unit) {
    Box(
        Modifier.size(40.dp).clip(CircleShape).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
        content = content,
    )
}

@Composable
private fun EmptyState(onPick: (String) -> Unit) {
    val prompts = listOf(
        "Объясни простыми словами, как работает нейросеть",
        "Придумай название для небольшой кофейни",
        "Помоги вежливо отказаться от встречи",
    )
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 26.dp, vertical = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        KalyptMark(84.dp)
        Spacer(Modifier.height(18.dp))
        Text("Kalypt", color = K.Mist, fontFamily = FontFamily.Serif, fontSize = 44.sp)
        Spacer(Modifier.height(10.dp))
        Text(
            "Нейросеть работает прямо на вашем телефоне. Переписка не уходит в интернет.",
            color = K.Haze, fontSize = 15.sp, lineHeight = 22.sp, textAlign = TextAlign.Center,
            modifier = Modifier.widthIn(max = 320.dp),
        )
        Spacer(Modifier.height(32.dp))
        prompts.forEach { p ->
            val shape = RoundedCornerShape(18.dp)
            Box(
                Modifier
                    .padding(vertical = 5.dp)
                    .widthIn(max = 420.dp)
                    .fillMaxWidth()
                    .clip(shape)
                    .border(1.dp, K.Line, shape)
                    .clickable { onPick(p) }
                    .padding(horizontal = 16.dp, vertical = 14.dp),
            ) {
                Text(p, color = K.Mist, fontSize = 15.sp, lineHeight = 21.sp)
            }
        }
    }
}

@Composable
private fun MessageRow(m: Msg, thinking: Boolean) {
    if (m.role == Role.User) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            Box(
                Modifier
                    .widthIn(max = 310.dp)
                    .clip(RoundedCornerShape(22.dp, 22.dp, 6.dp, 22.dp))
                    .background(K.VeilDeep)
                    .padding(horizontal = 16.dp, vertical = 12.dp),
            ) {
                Text(m.text, color = K.Mist, fontSize = 16.sp, lineHeight = 23.sp)
            }
        }
    } else {
        Row(Modifier.fillMaxWidth()) {
            KalyptMark(22.dp, Modifier.padding(top = 2.dp))
            Spacer(Modifier.width(12.dp))
            SelectionContainer(Modifier.weight(1f)) {
                when {
                    thinking -> Thinking()
                    m.isError -> Text(m.text, color = K.Danger, fontSize = 15.sp, lineHeight = 22.sp)
                    else -> Text(renderLite(m.text), color = K.Mist, fontSize = 16.sp, lineHeight = 24.sp)
                }
            }
        }
    }
}

@Composable
private fun Thinking() {
    val t = rememberInfiniteTransition(label = "think")
    val a by t.animateFloat(
        initialValue = 0.35f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(800), RepeatMode.Reverse), label = "a",
    )
    Text("Думаю…", color = K.Haze.copy(alpha = a), fontSize = 16.sp, lineHeight = 24.sp)
}

@Composable
private fun InputBar(
    value: String,
    onChange: (String) -> Unit,
    generating: Boolean,
    onSend: () -> Unit,
    onStop: () -> Unit,
) {
    val shape = RoundedCornerShape(26.dp)
    val canSend = value.isNotBlank()
    Row(
        Modifier.fillMaxWidth().navigationBarsPadding().imePadding().padding(12.dp),
        verticalAlignment = Alignment.Bottom,
    ) {
        Box(
            Modifier
                .weight(1f)
                .clip(shape)
                .background(K.Deep)
                .border(1.dp, K.Line, shape)
                .padding(horizontal = 18.dp, vertical = 13.dp),
        ) {
            if (value.isEmpty()) Text("Напишите сообщение", color = K.Haze, fontSize = 16.sp)
            BasicTextField(
                value = value,
                onValueChange = onChange,
                textStyle = TextStyle(color = K.Mist, fontSize = 16.sp, lineHeight = 22.sp),
                cursorBrush = SolidColor(K.Veil),
                maxLines = 5,
                keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences),
                modifier = Modifier.fillMaxWidth(),
            )
        }
        Spacer(Modifier.width(8.dp))
        val active = generating || canSend
        Box(
            Modifier
                .size(48.dp)
                .clip(CircleShape)
                .background(if (active) K.Veil else K.Raised)
                .clickable(enabled = active) { if (generating) onStop() else onSend() },
            contentAlignment = Alignment.Center,
        ) {
            Canvas(Modifier.size(20.dp)) {
                val c = if (active) K.Ink else K.Haze
                val w = size.width
                val h = size.height
                if (generating) {
                    drawRoundRect(
                        color = c,
                        topLeft = Offset(w * 0.15f, h * 0.15f),
                        size = Size(w * 0.7f, h * 0.7f),
                        cornerRadius = androidx.compose.ui.geometry.CornerRadius(3.dp.toPx()),
                    )
                } else {
                    val path = Path().apply {
                        moveTo(w * 0.5f, h * 0.9f)
                        lineTo(w * 0.5f, h * 0.14f)
                        moveTo(w * 0.14f, h * 0.48f)
                        lineTo(w * 0.5f, h * 0.12f)
                        lineTo(w * 0.86f, h * 0.48f)
                    }
                    drawPath(
                        path, c,
                        style = Stroke(width = 2.6.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round),
                    )
                }
            }
        }
    }
}

// ───────────────────────── О приложении ─────────────────────────

@Composable
private fun AboutDialog(onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = K.Deep,
        titleContentColor = K.Mist,
        textContentColor = K.Haze,
        confirmButton = { TextButton(onClick = onDismiss) { Text("Закрыть", color = K.Veil) } },
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                KalyptMark(30.dp)
                Spacer(Modifier.width(10.dp))
                Text("Kalypt AI", fontFamily = FontFamily.Serif, fontSize = 24.sp)
            }
        },
        text = {
            Column {
                Text("Создано ELUPON", color = K.Mist, fontSize = 16.sp)
                Spacer(Modifier.height(12.dp))
                Text(
                    "Локальный ИИ-ассистент на основе Qwen2.5 и llama.cpp. Все ответы генерируются на этом устройстве.",
                    fontSize = 14.sp, lineHeight = 20.sp,
                )
                Spacer(Modifier.height(12.dp))
                Text("Версия 0.2.0, лицензия MIT", fontSize = 13.sp)
            }
        },
    )
}

// ───────────────────────── Лёгкий Markdown ─────────────────────────

private fun renderLite(src: String): AnnotatedString = buildAnnotatedString {
    var inCode = false
    val lines = src.split("\n")
    lines.forEachIndexed { index, raw ->
        if (raw.trimStart().startsWith("```")) {
            inCode = !inCode
        } else {
            if (inCode) {
                withStyle(SpanStyle(fontFamily = FontFamily.Monospace, background = K.Deep, color = K.VeilSoft, fontSize = 14.sp)) {
                    append(raw)
                }
            } else {
                val t = raw.trimStart()
                val heading = t.takeWhile { it == '#' }
                when {
                    heading.isNotEmpty() && heading.length <= 6 && t.drop(heading.length).startsWith(" ") -> {
                        withStyle(SpanStyle(fontWeight = FontWeight.SemiBold)) {
                            appendInline(t.drop(heading.length).trim())
                        }
                    }
                    t.startsWith("- ") || (t.startsWith("* ") && !t.startsWith("**")) -> {
                        append("•  ")
                        appendInline(t.drop(2))
                    }
                    else -> appendInline(raw)
                }
            }
            if (index < lines.lastIndex) append("\n")
        }
    }
}

private fun AnnotatedString.Builder.appendInline(s: String) {
    var i = 0
    while (i < s.length) {
        if (s.startsWith("**", i)) {
            val end = s.indexOf("**", i + 2)
            if (end > 0) {
                withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { append(s.substring(i + 2, end)) }
                i = end + 2
                continue
            }
        }
        if (s[i] == '`') {
            val end = s.indexOf('`', i + 1)
            if (end > 0) {
                withStyle(SpanStyle(fontFamily = FontFamily.Monospace, background = K.Deep, color = K.VeilSoft)) {
                    append(s.substring(i + 1, end))
                }
                i = end + 1
                continue
            }
        }
        append(s[i])
        i++
    }
}
