// Kalypt AI by ELUPON: JNI-мост к llama.cpp
#include <jni.h>
#include <android/log.h>

#include <algorithm>
#include <cstdint>
#include <string>
#include <vector>

#include "llama.h"

#define LOG_TAG "KalyptNative"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

namespace {

llama_model *g_model = nullptr;
llama_context *g_ctx = nullptr;
llama_sampler *g_smpl = nullptr;
const llama_vocab *g_vocab = nullptr;
int g_n_past = 0;
int g_n_ctx = 0;
int g_n_batch = 512;

void release_all() {
    if (g_smpl) { llama_sampler_free(g_smpl); g_smpl = nullptr; }
    if (g_ctx) { llama_free(g_ctx); g_ctx = nullptr; }
    if (g_model) { llama_model_free(g_model); g_model = nullptr; }
    g_vocab = nullptr;
    g_n_past = 0;
}

llama_sampler *make_sampler() {
    llama_sampler *s = llama_sampler_chain_init(llama_sampler_chain_default_params());
    llama_sampler_chain_add(s, llama_sampler_init_penalties(64, 1.1f, 0.0f, 0.0f));
    llama_sampler_chain_add(s, llama_sampler_init_top_k(40));
    llama_sampler_chain_add(s, llama_sampler_init_top_p(0.9f, 1));
    llama_sampler_chain_add(s, llama_sampler_init_temp(0.7f));
    llama_sampler_chain_add(s, llama_sampler_init_dist(LLAMA_DEFAULT_SEED));
    return s;
}

// UTF-16 (jstring) -> UTF-8, с поддержкой суррогатных пар (эмодзи).
std::string to_utf8(const jchar *s, jsize n) {
    std::string out;
    out.reserve(static_cast<size_t>(n) * 3);
    for (jsize i = 0; i < n; i++) {
        uint32_t cp = s[i];
        if (cp >= 0xD800 && cp <= 0xDBFF && i + 1 < n && s[i + 1] >= 0xDC00 && s[i + 1] <= 0xDFFF) {
            cp = 0x10000 + ((cp - 0xD800) << 10) + (static_cast<uint32_t>(s[i + 1]) - 0xDC00);
            i++;
        }
        if (cp < 0x80) {
            out.push_back(static_cast<char>(cp));
        } else if (cp < 0x800) {
            out.push_back(static_cast<char>(0xC0 | (cp >> 6)));
            out.push_back(static_cast<char>(0x80 | (cp & 0x3F)));
        } else if (cp < 0x10000) {
            out.push_back(static_cast<char>(0xE0 | (cp >> 12)));
            out.push_back(static_cast<char>(0x80 | ((cp >> 6) & 0x3F)));
            out.push_back(static_cast<char>(0x80 | (cp & 0x3F)));
        } else {
            out.push_back(static_cast<char>(0xF0 | (cp >> 18)));
            out.push_back(static_cast<char>(0x80 | ((cp >> 12) & 0x3F)));
            out.push_back(static_cast<char>(0x80 | ((cp >> 6) & 0x3F)));
            out.push_back(static_cast<char>(0x80 | (cp & 0x3F)));
        }
    }
    return out;
}

// Возвращает длину самого длинного корректного UTF-8 префикса.
// Битые байты заменяются на '?', неполный хвост остаётся ждать следующий токен.
size_t utf8_valid_prefix(std::string &s) {
    size_t i = 0;
    const size_t n = s.size();
    while (i < n) {
        unsigned char c = static_cast<unsigned char>(s[i]);
        size_t len = c < 0x80 ? 1 : (c >> 5) == 6 ? 2 : (c >> 4) == 14 ? 3 : (c >> 3) == 30 ? 4 : 0;
        if (len == 0) { s[i] = '?'; i++; continue; }
        if (i + len > n) break;
        bool ok = true;
        for (size_t k = 1; k < len; k++) {
            if ((static_cast<unsigned char>(s[i + k]) & 0xC0) != 0x80) { ok = false; break; }
        }
        if (!ok) { s[i] = '?'; i++; continue; }
        i += len;
    }
    return i;
}

std::u16string to_utf16(const std::string &s) {
    std::u16string out;
    size_t i = 0;
    while (i < s.size()) {
        unsigned char c = static_cast<unsigned char>(s[i]);
        uint32_t cp;
        size_t len;
        if (c < 0x80) { cp = c; len = 1; }
        else if ((c >> 5) == 6) { cp = c & 0x1F; len = 2; }
        else if ((c >> 4) == 14) { cp = c & 0x0F; len = 3; }
        else { cp = c & 0x07; len = 4; }
        for (size_t k = 1; k < len && i + k < s.size(); k++) {
            cp = (cp << 6) | (static_cast<unsigned char>(s[i + k]) & 0x3F);
        }
        i += len;
        if (cp >= 0x10000) {
            cp -= 0x10000;
            out.push_back(static_cast<char16_t>(0xD800 + (cp >> 10)));
            out.push_back(static_cast<char16_t>(0xDC00 + (cp & 0x3FF)));
        } else {
            out.push_back(static_cast<char16_t>(cp));
        }
    }
    return out;
}

void android_log_cb(ggml_log_level level, const char *text, void *) {
    if (level >= GGML_LOG_LEVEL_WARN) {
        __android_log_print(ANDROID_LOG_WARN, "llama", "%s", text);
    }
}

}  // namespace

extern "C" JNIEXPORT jboolean JNICALL
Java_com_kalypt_app_LlamaBridge_load(JNIEnv *env, jobject, jstring jpath, jint nCtx, jint nThreads) {
    release_all();
    llama_log_set(android_log_cb, nullptr);
    llama_backend_init();

    const char *path = env->GetStringUTFChars(jpath, nullptr);
    llama_model_params mp = llama_model_default_params();
    mp.n_gpu_layers = 0;
    mp.use_mmap = true;
    g_model = llama_model_load_from_file(path, mp);
    env->ReleaseStringUTFChars(jpath, path);
    if (!g_model) {
        LOGE("model load failed");
        return JNI_FALSE;
    }

    g_n_ctx = nCtx;
    llama_context_params cp = llama_context_default_params();
    cp.n_ctx = static_cast<uint32_t>(nCtx);
    cp.n_batch = static_cast<uint32_t>(g_n_batch);
    cp.n_ubatch = static_cast<uint32_t>(g_n_batch);
    cp.n_threads = nThreads;
    cp.n_threads_batch = nThreads;
    g_ctx = llama_init_from_model(g_model, cp);
    if (!g_ctx) {
        LOGE("context init failed");
        release_all();
        return JNI_FALSE;
    }

    g_vocab = llama_model_get_vocab(g_model);
    g_smpl = make_sampler();
    g_n_past = 0;
    LOGI("model loaded, ctx=%d threads=%d", nCtx, nThreads);
    return JNI_TRUE;
}

// Возврат: число сгенерированных токенов, -1 нет модели, -2 промпт не влезает, -3 ошибка decode, -4 ошибка токенизации.
extern "C" JNIEXPORT jint JNICALL
Java_com_kalypt_app_LlamaBridge_generate(JNIEnv *env, jobject, jstring jprompt, jint maxTokens, jobject cb) {
    if (!g_ctx || !g_model) return -1;

    const jchar *chars = env->GetStringChars(jprompt, nullptr);
    std::string prompt = to_utf8(chars, env->GetStringLength(jprompt));
    env->ReleaseStringChars(jprompt, chars);

    const bool first = (g_n_past == 0);
    int n = -llama_tokenize(g_vocab, prompt.c_str(), static_cast<int32_t>(prompt.size()),
                            nullptr, 0, first, true);
    if (n <= 0) return -4;
    std::vector<llama_token> tokens(static_cast<size_t>(n));
    if (llama_tokenize(g_vocab, prompt.c_str(), static_cast<int32_t>(prompt.size()),
                       tokens.data(), n, first, true) < 0) {
        return -4;
    }

    if (g_n_past + n + 16 >= g_n_ctx) return -2;

    for (int i = 0; i < n; i += g_n_batch) {
        int cnt = std::min(g_n_batch, n - i);
        llama_batch batch = llama_batch_get_one(tokens.data() + i, cnt);
        if (llama_decode(g_ctx, batch) != 0) return -3;
        g_n_past += cnt;
    }

    jclass cbClass = env->FindClass("com/kalypt/app/TokenCallback");
    jmethodID onToken = env->GetMethodID(cbClass, "onToken", "(Ljava/lang/String;)Z");

    std::string pending;
    int produced = 0;
    const int limit = std::min<int>(maxTokens, g_n_ctx - g_n_past - 2);

    while (produced < limit) {
        llama_token tok = llama_sampler_sample(g_smpl, g_ctx, -1);
        if (llama_vocab_is_eog(g_vocab, tok)) break;

        std::string piece(256, '\0');
        int len = llama_token_to_piece(g_vocab, tok, &piece[0], static_cast<int32_t>(piece.size()), 0, true);
        if (len < 0) {
            piece.resize(static_cast<size_t>(-len));
            len = llama_token_to_piece(g_vocab, tok, &piece[0], static_cast<int32_t>(piece.size()), 0, true);
        }
        if (len > 0) pending.append(piece.data(), static_cast<size_t>(len));

        llama_batch batch = llama_batch_get_one(&tok, 1);
        if (llama_decode(g_ctx, batch) != 0) break;
        g_n_past++;
        produced++;

        size_t valid = utf8_valid_prefix(pending);
        if (valid > 0) {
            std::u16string u16 = to_utf16(pending.substr(0, valid));
            pending.erase(0, valid);
            jstring js = env->NewString(reinterpret_cast<const jchar *>(u16.data()),
                                        static_cast<jsize>(u16.size()));
            jboolean cont = env->CallBooleanMethod(cb, onToken, js);
            env->DeleteLocalRef(js);
            if (env->ExceptionCheck()) { env->ExceptionClear(); break; }
            if (!cont) break;
        }
    }
    return produced;
}

extern "C" JNIEXPORT void JNICALL
Java_com_kalypt_app_LlamaBridge_reset(JNIEnv *, jobject) {
    if (g_ctx) {
        llama_memory_clear(llama_get_memory(g_ctx), true);
    }
    if (g_smpl) llama_sampler_reset(g_smpl);
    g_n_past = 0;
}

extern "C" JNIEXPORT jint JNICALL
Java_com_kalypt_app_LlamaBridge_nPast(JNIEnv *, jobject) {
    return g_n_past;
}

extern "C" JNIEXPORT void JNICALL
Java_com_kalypt_app_LlamaBridge_release(JNIEnv *, jobject) {
    release_all();
}
