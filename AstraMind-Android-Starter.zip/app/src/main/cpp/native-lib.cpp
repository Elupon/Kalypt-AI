#include <jni.h>
#include <string>
#include <vector>
#include <mutex>
#include <algorithm>
#include <thread>
#include "llama.h"

static llama_model * g_model = nullptr;
static std::mutex g_mutex;

static std::string fromJString(JNIEnv * env, jstring value) {
    if (!value) return {};
    const char * chars = env->GetStringUTFChars(value, nullptr);
    std::string result = chars ? chars : "";
    if (chars) env->ReleaseStringUTFChars(value, chars);
    return result;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_astramind_app_LlamaEngine_nativeLoadModel(JNIEnv * env, jobject, jstring path) {
    std::lock_guard<std::mutex> lock(g_mutex);
    const std::string modelPath = fromJString(env, path);
    if (modelPath.empty()) return JNI_FALSE;
    if (g_model) {
        llama_model_free(g_model);
        g_model = nullptr;
    }
    llama_backend_init();
    llama_model_params modelParams = llama_model_default_params();
    modelParams.n_gpu_layers = 0; // CPU-first baseline; Vulkan/OpenCL can be added separately.
    g_model = llama_model_load_from_file(modelPath.c_str(), modelParams);
    return g_model ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_astramind_app_LlamaEngine_nativeGenerate(JNIEnv * env, jobject, jstring promptValue) {
    std::lock_guard<std::mutex> lock(g_mutex);
    if (!g_model) return env->NewStringUTF("Сначала выбери GGUF-модель.");

    const std::string userPrompt = fromJString(env, promptValue);
    const std::string prompt =
        "<|im_start|>system\nТы AstraMind, полезный ИИ-ассистент. Отвечай на языке пользователя.\n<|im_end|>\n"
        "<|im_start|>user\n" + userPrompt + "\n<|im_end|>\n<|im_start|>assistant\n";

    llama_context_params ctxParams = llama_context_default_params();
    ctxParams.n_ctx = 2048;
    ctxParams.n_batch = 512;
    ctxParams.n_ubatch = 512;
    ctxParams.n_threads = std::max(2u, std::min(4u, std::thread::hardware_concurrency()));
    ctxParams.n_threads_batch = ctxParams.n_threads;
    llama_context * ctx = llama_init_from_model(g_model, ctxParams);
    if (!ctx) return env->NewStringUTF("Не удалось создать контекст модели. Попробуй меньшую GGUF-модель.");

    const llama_vocab * vocab = llama_model_get_vocab(g_model);
    std::vector<llama_token> tokens(8192);
    int32_t count = llama_tokenize(vocab, prompt.c_str(), (int32_t) prompt.size(), tokens.data(), (int32_t) tokens.size(), true, false);
    if (count < 0) {
        tokens.resize((size_t)(-count));
        count = llama_tokenize(vocab, prompt.c_str(), (int32_t) prompt.size(), tokens.data(), (int32_t) tokens.size(), true, false);
    }
    if (count <= 0 || count > 2000) {
        llama_free(ctx);
        return env->NewStringUTF("Сообщение слишком длинное для текущего контекста.");
    }

    llama_batch batch = llama_batch_get_one(tokens.data(), count);
    if (llama_decode(ctx, batch) != 0) {
        llama_free(ctx);
        return env->NewStringUTF("Ошибка обработки запроса моделью.");
    }

    llama_sampler_chain_params samplerParams = llama_sampler_chain_default_params();
    llama_sampler * sampler = llama_sampler_chain_init(samplerParams);
    llama_sampler_chain_add(sampler, llama_sampler_init_top_k(40));
    llama_sampler_chain_add(sampler, llama_sampler_init_top_p(0.9f, 1));
    llama_sampler_chain_add(sampler, llama_sampler_init_temp(0.7f));
    llama_sampler_chain_add(sampler, llama_sampler_init_dist(LLAMA_DEFAULT_SEED));

    std::string answer;
    for (int i = 0; i < 384; ++i) {
        const llama_token token = llama_sampler_sample(sampler, ctx, -1);
        if (llama_vocab_is_eog(vocab, token)) break;
        char piece[256];
        int32_t pieceLen = llama_token_to_piece(vocab, token, piece, sizeof(piece), 0, false);
        if (pieceLen > 0) answer.append(piece, (size_t)pieceLen);
        llama_token nextToken = token;
        if (llama_decode(ctx, llama_batch_get_one(&nextToken, 1)) != 0) break;
    }

    llama_sampler_free(sampler);
    llama_free(ctx);
    if (answer.empty()) answer = "Модель не вернула текст. Проверь формат GGUF и попробуй ещё раз.";
    return env->NewStringUTF(answer.c_str());
}

extern "C" JNIEXPORT void JNICALL
Java_com_astramind_app_LlamaEngine_nativeUnloadModel(JNIEnv *, jobject) {
    std::lock_guard<std::mutex> lock(g_mutex);
    if (g_model) {
        llama_model_free(g_model);
        g_model = nullptr;
    }
}
