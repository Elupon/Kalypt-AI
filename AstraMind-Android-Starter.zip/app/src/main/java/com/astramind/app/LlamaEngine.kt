package com.astramind.app

/** Thin JNI bridge to llama.cpp. All expensive calls must run off the UI thread. */
class LlamaEngine {
    external fun nativeLoadModel(path: String): Boolean
    external fun nativeGenerate(prompt: String): String
    external fun nativeUnloadModel()

    companion object {
        init {
            System.loadLibrary("astramind")
        }
    }
}
