package com.astramind.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

private data class ChatMessage(val text: String, val fromUser: Boolean)

class MainActivity : ComponentActivity() {
    private val engine by lazy { LlamaEngine() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                AstraMindScreen(
                    onChooseModel = { uri, onStatus, onLoaded -> loadModel(uri, onStatus, onLoaded) },
                    onGenerate = { prompt -> withContext(Dispatchers.IO) { engine.nativeGenerate(prompt) } }
                )
            }
        }
    }

    private fun loadModel(uri: Uri, onStatus: (String) -> Unit, onLoaded: (Boolean, String) -> Unit) {
        lifecycleScope.launch {
            onStatus("Копирование GGUF-файла…")
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    val modelsDir = File(filesDir, "models").apply { mkdirs() }
                    val destination = File(modelsDir, "selected-model.gguf")
                    contentResolver.openInputStream(uri).use { input ->
                        requireNotNull(input) { "Не удалось открыть выбранный файл." }
                        destination.outputStream().use { output -> input.copyTo(output) }
                    }
                    require(destination.length() > 1024 * 1024) { "Файл слишком маленький или пустой." }
                    check(engine.nativeLoadModel(destination.absolutePath)) {
                        "llama.cpp не смог открыть модель. Проверь, что это совместимый GGUF-файл."
                    }
                    destination.name
                }
            }
            result.onSuccess { onLoaded(true, "Qwen / GGUF загружена: $it") }
                .onFailure { onLoaded(false, "Ошибка загрузки: ${it.message ?: "неизвестная ошибка"}") }
        }
    }

    override fun onDestroy() {
        if (isFinishing) lifecycleScope.launch(Dispatchers.IO) { runCatching { engine.nativeUnloadModel() } }
        super.onDestroy()
    }
}

@Composable
private fun AstraMindScreen(
    onChooseModel: (Uri, (String) -> Unit, (Boolean, String) -> Unit) -> Unit,
    onGenerate: suspend (String) -> String
) {
    var input by remember { mutableStateOf("") }
    var modelStatus by remember { mutableStateOf("Модель не загружена") }
    var isModelReady by remember { mutableStateOf(false) }
    var isBusy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val messages = remember { mutableStateListOf(ChatMessage("Привет! Я AstraMind. Выбери GGUF-модель Qwen, чтобы начать общение локально.", false)) }

    val modelPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            onChooseModel(uri, { modelStatus = it }, { success, status ->
                isModelReady = success
                modelStatus = status
                if (success) messages.add(ChatMessage("Модель загружена. Теперь я могу отвечать локально на устройстве.", false))
            })
        }
    }

    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("AstraMind", style = MaterialTheme.typography.headlineMedium)
        Text(modelStatus, style = MaterialTheme.typography.bodySmall)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Button(onClick = { modelPicker.launch(arrayOf("application/octet-stream", "application/*", "*/*")) }, enabled = !isBusy) {
                Text("Выбрать GGUF-модель")
            }
            if (isModelReady) {
                Spacer(Modifier.width(8.dp))
                Text("Готова", color = MaterialTheme.colorScheme.primary)
            }
        }
        HorizontalDivider()
        LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(messages) { message ->
                Surface(
                    color = if (message.fromUser) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                    shape = MaterialTheme.shapes.medium
                ) { Text(message.text, modifier = Modifier.padding(12.dp)) }
            }
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Напиши сообщение…") },
                maxLines = 4,
                enabled = !isBusy
            )
            Button(
                enabled = isModelReady && !isBusy && input.isNotBlank(),
                onClick = {
                    val prompt = input.trim()
                    input = ""
                    messages.add(ChatMessage(prompt, true))
                    isBusy = true
                    scope.launch {
                        val answer = withContext(Dispatchers.IO) { runCatching { onGenerate(prompt) } }
                            .fold({ it }, { "Ошибка генерации: ${it.message ?: "неизвестная ошибка"}" })
                        messages.add(ChatMessage(answer, false))
                        isBusy = false
                    }
                }
            ) { Text(if (isBusy) "Думаю…" else "Отправить") }
        }
    }
}
